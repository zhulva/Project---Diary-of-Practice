<?php

require_once __DIR__.'/vendor/.composer/autoload.php';

$config = new \Doctrine\ORM\Configuration();
$config->setMetadataCacheImpl(new \Doctrine\Common\Cache\ArrayCache);
$driverImpl = $config->newDefaultAnnotationDriver(array(__DIR__."/src/Acme/Demo/Entities")); // change to your entity path
$config->setMetadataDriverImpl($driverImpl);
$config->setProxyDir(__DIR__ . '/src/Acme/Demo/Proxies'); // change to your proxy path
$config->setProxyNamespace('Proxies');

// use your db options
$connectionOptions = array(
    'driver' => 'pdo_sqlite',
    'path' => 'database.sqlite'
);

$em = \Doctrine\ORM\EntityManager::create($connectionOptions, $config);

$helpers = array(
    'db' => new \Doctrine\DBAL\Tools\Console\Helper\ConnectionHelper($em->getConnection()),
    'em' => new \Doctrine\ORM\Tools\Console\Helper\EntityManagerHelper($em)
);