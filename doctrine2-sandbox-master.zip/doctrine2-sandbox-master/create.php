<?php

require __DIR__ . '/autoload.php';

$user = new Acme\Demo\Entities\User();
$user->setName('Garfield');
$em->persist($user);
$em->flush();

echo "User saved!";