### Install vendors

    php bin/vendors install

### Doctrine command line

    php doctrine.php

### Create db/schema

    php doctrine.php orm:schema-tool:create

### Create test user

    php create.php

### Fetch test user

    php fetch.php