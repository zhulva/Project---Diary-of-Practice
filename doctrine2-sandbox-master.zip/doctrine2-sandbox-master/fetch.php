<?php

require __DIR__ . '/autoload.php';

$q = $em->createQuery('select u from Acme\Demo\Entities\User u where u.name = ?1');
$q->setParameter(1, 'Garfield');
$garfield = $q->getSingleResult();

echo "Hello " . $garfield->getName() . "!";